package com.example.feuilledereponses;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.WindowInsets;
public class MainActivity extends Activity {
 protected void onCreate(Bundle b){
  super.onCreate(b);
  WebView w=new WebView(this);
  w.setWebViewClient(new WebViewClient());
  WebSettings s=w.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  w.setOnApplyWindowInsetsListener((v, insets) -> {
   if (android.os.Build.VERSION.SDK_INT >= 30) {
    int bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
    v.setPadding(0, 0, 0, bottom);
   }
   return insets;
  });
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
}
